﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CaRental.Models;

namespace CaRental.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarModelsController : ControllerBase
    {
        private readonly IdentityContext _context;
        private readonly ICarModelsRepository _carModelRepository;

        public CarModelsController(IdentityContext context, ICarModelsRepository carModelsRepository)
        {
            _context = context;
            _carModelRepository = carModelsRepository;
        }

        // GET: api/CarModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CarModels>>> GetCar()
        {
            return _carModelRepository.AllCar.ToList();
        }

        // GET: api/CarModels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CarModels>> GetCarModels(int id)
        {
            var carModels = await _context.Car.FindAsync(id);

            if (carModels == null)
            {
                return NotFound();
            }

            return carModels;
        }

        // PUT: api/CarModels/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCarModels(int id, CarModels carModels)
        {
            if (id != carModels.IdCar)
            {
                return BadRequest();
            }

            _context.Entry(carModels).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CarModelsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CarModels
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<CarModels>> PostCarModels(CarModels carModels)
        {
            _context.Car.Add(carModels);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCarModels", new { id = carModels.IdCar }, carModels);
        }

        // DELETE: api/CarModels/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<CarModels>> DeleteCarModels(int id)
        {
            var carModels = await _context.Car.FindAsync(id);
            if (carModels == null)
            {
                return NotFound();
            }

            _context.Car.Remove(carModels);
            await _context.SaveChangesAsync();

            return carModels;
        }

        private bool CarModelsExists(int id)
        {
            return _context.Car.Any(e => e.IdCar == id);
        }
    }
}
