﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CaRental.Models;
using Microsoft.AspNetCore.Authorization;

namespace CaRental.Controllers
{   
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PersonModelsController : ControllerBase
    {
        private readonly IdentityContext _context;

        public PersonModelsController(IdentityContext context)
        {
            _context = context;
        }




        // GET: api/PersonModels
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PersonModels>>> GetPerson()
        {
            return await _context.Person.ToListAsync();
        }

        // GET: api/PersonModels/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PersonModels>> GetPersonModels(int id)
        {
            var personModels = await _context.Person.FindAsync(id);

            if (personModels == null)
            {
                return NotFound();
            }

            return personModels;
        }

        // PUT: api/PersonModels/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPersonModels(int id, PersonModels personModels)
        {
            if (id != personModels.UserId)
            {
                return BadRequest();
            }

            _context.Entry(personModels).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PersonModelsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/PersonModels
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<PersonModels>> PostPersonModels(PersonModels personModels)
        {
            _context.Person.Add(personModels);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetPersonModels), new { id = personModels.UserId }, personModels);
        }

        // DELETE: api/PersonModels/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<PersonModels>> DeletePersonModels(int id)
        {
            var personModels = await _context.Person.FindAsync(id);
            if (personModels == null)
            {
                return NotFound();
            }

            _context.Person.Remove(personModels);
            await _context.SaveChangesAsync();

            return personModels;
        }

        private bool PersonModelsExists(int id)
        {
            return _context.Person.Any(e => e.UserId == id);
        }
    }
}
