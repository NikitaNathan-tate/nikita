﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace CaRental.Models
{
   
        public class CarModelsRepository : ICarModelsRepository

    {
        private readonly IdentityContext _appDbContext;

            public CarModelsRepository(IdentityContext appDbContext)
            {
                _appDbContext = appDbContext;
            }

       
       

        public IEnumerable<CarModels> AllCar
        {
            get
            {
                return _appDbContext.Car.ToList();
            }
        }
}

}

