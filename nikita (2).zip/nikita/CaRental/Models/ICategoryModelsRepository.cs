﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaRental.Models
{
    public interface ICategoryModelsRepository
    {
        IEnumerable<CategoryModels> AllCategories { get; }
    }
}
